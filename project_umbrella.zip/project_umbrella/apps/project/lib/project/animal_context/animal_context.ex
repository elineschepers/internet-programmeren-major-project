defmodule Project.AnimalContext do
    alias Project.AnimalContext.Animal
    alias Project.Repo
    alias Project.UserContext.User
    @doc "Returns a animal changeset"
    def change_animal(%Animal{} = animal) do
      animal |> Animal.changeset(%{})
    end
  
    @doc "Creates a animal based on some external attributes"
    def create_animal(attrs, %User{} = user) do
      %Animal{}
      |> Animal.create_changeset(attrs, user)
      |> Repo.insert()
    end
     @doc "Returns a specific animal or raises an error"
  def get_animal!(id), do: Repo.get!(Animal, id)

  @doc "Returns all animals in the system"
  def list_animals, do: Repo.all(Animal)

  @doc "Update an existing animal with external attributes"
  def update_animal(%Animal{} = animal, attrs) do
    animal
    |> Animal.changeset(attrs)
    |> Repo.update()
  end

 @doc "Delete a animal"
 def delete_animal(%Animal{} = animal), do: Repo.delete(animal)

end

  