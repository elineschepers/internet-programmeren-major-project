defmodule ProjectWeb.PageViewTest do
  use ProjectWeb.ConnCase, async: true
end
