defmodule ProjectWeb.Router do
  use ProjectWeb, :router

  pipeline :browser do
    plug :accepts, ["html"]
    plug :fetch_session
    plug :fetch_flash
    plug :protect_from_forgery
    plug :put_secure_browser_headers
    plug ProjectWeb.Plugs.Locale
  end

  pipeline :api do
    plug :accepts, ["json"]
  end

  pipeline :auth do
    plug ProjectWeb.Pipeline
  end

  pipeline :ensure_auth do
    plug Guardian.Plug.EnsureAuthenticated
  end

  pipeline :allowed_for_users do
    plug ProjectWeb.Plugs.AuthorizationPlug, ["Admin", "Manager", "User"]
  end

  pipeline :allowed_for_managers do
    plug ProjectWeb.Plugs.AuthorizationPlug, ["Admin", "Manager"]
  end

  pipeline :allowed_for_admins do
    plug ProjectWeb.Plugs.AuthorizationPlug, ["Admin"]
  end

  scope "/", ProjectWeb do
    pipe_through [:browser,:auth]

    get "/", PageController, :index
    get "/login", SessionController, :new
    post "/login", SessionController, :login
    get "/logout", SessionController, :logout
  end

  scope "/",ProjectWeb do
    pipe_through [:browser, :auth, :ensure_auth, :allowed_for_users]

    get "/user_scope", PageController, :user_index
  end

  scope "/", ProjectWeb do
    pipe_through [:browser, :auth, :ensure_auth, :allowed_for_managers]

    get "/manager_scope", PageController, :manager_index
  end

  scope "/admin", ProjectWeb do
    pipe_through [:browser, :auth, :ensure_auth, :allowed_for_admins]

    resources "/users", UserController
    get "/", PageController, :admin_index
  end

  scope "/", ProjectWeb do
    pipe_through [:browser]
    get "/animals/new", AnimalController, :new
    post "/animals", AnimalController, :create
    get "/animals", AnimalController, :index
    get "/animals/:animal_id", AnimalController, :show
    
    get "/animals/:animal_id/edit", AnimalController, :edit
    put "/animals/:animal_id", AnimalController, :update
    patch "/animals/:animal_id", AnimalController, :update
    delete "/animals/:animal_id", AnimalController, :delete
  end
"""
  scope "/" -> resources "/users" => is for the html interface to edit our users.
  scope "/api" -> resources "/users", only: [] => means that we're generating routes for our user as well. Thanks to the resources macro, we can configure this and say that we don't want REST routes for the users resource.
  resources "/cats", CatController => means that we're going to allow (nested if it is inside another resources block) cat routes for our REST API.
  """
scope "/api", ProjectWeb do
  pipe_through :api

  resources "/users", UserController, only: [] do 
    resources "/animals", AnimalController

 end  
end



  # Other scopes may use custom stacks.
  # scope "/api", ProjectWeb do
  #   pipe_through :api
  # end
  end