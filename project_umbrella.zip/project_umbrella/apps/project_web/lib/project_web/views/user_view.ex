defmodule ProjectWeb.UserView do
  use ProjectWeb, :view
end
