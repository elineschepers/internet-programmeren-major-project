defmodule ProjectWeb.PageView do
  use ProjectWeb, :view
end
