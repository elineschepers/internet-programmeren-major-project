defmodule ProjectWeb.SessionView do
    use ProjectWeb, :view
  end