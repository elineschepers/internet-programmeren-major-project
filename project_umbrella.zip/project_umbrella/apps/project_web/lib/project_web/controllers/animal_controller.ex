defmodule ProjectWeb.AnimalController do
    use ProjectWeb, :controller
  
    alias Project.AnimalContext
    alias Project.AnimalContext.Animal
  
    def new(conn, _parameters) do
      changeset = AnimalContext.change_animal(%Animal{})
      render(conn, "new.html", changeset: changeset)
    end
  
    def create(conn, %{"user_id"=> user_id, "animal" => animal_params}) do
      user=UserContext.get_user!(user_id)
      case AnimalContext.create_animal(animal_params,user) do
        {:ok, %Animal{}= animal} ->
          conn
          |> put_status(:created)
          |> put_resp_header("location",Routes.animal_path(conn, :show, user_id, animal))
          |> render("show.json", animal: animal)
  
        {:error, %Ecto.Changeset{} = changeset} ->
          render(conn, "new.html", changeset: changeset)
      end
    end
    #eerst retrieven we de user en laden daarna zijn animals
    def index(conn, %{"user_id" => user_id}) do
      user = UserContext.get_user!(user_id)
      user_with_loaded_animals = AnimalContext.load_animals(user)
      render(conn, "index.json", animals: user_with_loaded_animals.animals)
    end
    
    def show(conn, %{"id" => id}) do
      animal =AnimalContext.get_animal!(id)
      render(conn, "show.json", animal: animal)
    end

      def edit(conn, %{"animal_id" => id}) do
        animal = AnimalContext.get_animal!(id)
        changeset = AnimalContext.change_animal(animal)
        render(conn, "edit.html", animal: animal, changeset: changeset)
      end
    
      def update(conn, %{"id" => id, "animal" => animal_params}) do
        animal = AnimalContext.get_animal!(id)
    
        case AnimalContext.update_animal(animal, animal_params) do
          {:ok, %Animal{} = animal} ->
            render(conn, "show.json", animal: animal)
    
          {:error, _cs} ->
            conn
            |> send_resp(400, "Something went wrong, sorry. Adjust your parameters or give up.")
        end
      end
      def delete(conn, %{"animal_id" => id}) do 
        animal = AnimalContext.get_animal!(id)
        with {:ok, %Animal{}} <- AnimalContext.delete_animal(animal) do
          send_resp(conn, :no_content, "")
    
        end
        
        conn
        |> put_flash(:info, "Animal deleted successfully.")
        |> redirect(to: Routes.animal_path(conn, :index))
      end
    
  end